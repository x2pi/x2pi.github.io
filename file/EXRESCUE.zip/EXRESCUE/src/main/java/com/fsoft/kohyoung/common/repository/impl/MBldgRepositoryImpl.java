package com.fsoft.kohyoung.common.repository.impl;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.fsoft.kohyoung.common.abstracts.BaseRepository;
import com.fsoft.kohyoung.common.entity.MBldg;
import com.fsoft.kohyoung.common.repository.MBldgRepository;

/**
 * @author DungTM8
 *
 */
@Repository
public class MBldgRepositoryImpl extends BaseRepository implements MBldgRepository {

    @SuppressWarnings("unchecked")
    @Override
    public List<MBldg> getLstBldg(String uselevel, String soshiki, long company) {

        List<MBldg> litBldg = new ArrayList<>();
        String query = "SELECT * FROM m_bldg bl ";
        litBldg = entityManager.createNativeQuery(query, MBldg.class).getResultList();
        return litBldg;
    }
}