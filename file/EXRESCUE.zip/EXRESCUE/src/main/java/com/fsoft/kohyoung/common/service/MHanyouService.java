package com.fsoft.kohyoung.common.service;

import java.util.List;
import com.fsoft.kohyoung.common.entity.MHanyou;;

/**
 * MHanyou Service
 * 
 * @author DungTM8
 */
public interface MHanyouService {

    public abstract List<MHanyou> selectLstBunruiCd(String paramString);
}