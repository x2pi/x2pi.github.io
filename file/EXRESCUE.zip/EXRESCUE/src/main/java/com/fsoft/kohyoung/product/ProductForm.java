package com.fsoft.kohyoung.product;

public class ProductForm {
	private String groupPro;
	private String companyPro;
	private String organization;
	private String building;
	private String address;
	private String floor;
	private String location;
	private String drawSave;
	private String saveFile;
	private String type1;
	private String type2;
	private String namePro;
	private String quantity;
	private String condition;
	private String unit;
	private String numberOfBox;
	private String theQuantityOfEachBox;
	private String savingTime;
	private String acceptExpiry;
	private boolean acceptExpiryCB;
	private boolean transposted;
	private String remarks;
	private String attached;
	private String lastDateUpdate;
	private String hours;
	private String minute;
	
	public boolean isAcceptExpiryCB() {
		return acceptExpiryCB;
	}
	public void setAcceptExpiryCB(boolean acceptExpiryCB) {
		this.acceptExpiryCB = acceptExpiryCB;
	}
	public String getSaveFile() {
		return saveFile;
	}
	public void setSaveFile(String saveFile) {
		this.saveFile = saveFile;
	}
	public String getLastDateUpdate() {
		return lastDateUpdate;
	}
	public void setLastDateUpdate(String lastDateUpdate) {
		this.lastDateUpdate = lastDateUpdate;
	}
	public String getHours() {
		return hours;
	}
	public void setHours(String hours) {
		this.hours = hours;
	}
	public String getMinute() {
		return minute;
	}
	public void setMinute(String minute) {
		this.minute = minute;
	}
	public String getAttached() {
		return attached;
	}
	public void setAttached(String attached) {
		this.attached = attached;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public String getGroupPro() {
		return groupPro;
	}
	public void setGroupPro(String groupPro) {
		this.groupPro = groupPro;
	}
	public String getCompanyPro() {
		return companyPro;
	}
	public void setCompanyPro(String companyPro) {
		this.companyPro = companyPro;
	}
	public String getOrganization() {
		return organization;
	}
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	public String getBuilding() {
		return building;
	}
	public void setBuilding(String building) {
		this.building = building;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getFloor() {
		return floor;
	}
	public void setFloor(String floor) {
		this.floor = floor;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDrawSave() {
		return drawSave;
	}
	public void setDrawSave(String drawSave) {
		this.drawSave = drawSave;
	}
	public String getType1() {
		return type1;
	}
	public void setType1(String type1) {
		this.type1 = type1;
	}
	public String getType2() {
		return type2;
	}
	public void setType2(String type2) {
		this.type2 = type2;
	}
	public String getNamePro() {
		return namePro;
	}
	public void setNamePro(String namePro) {
		this.namePro = namePro;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getNumberOfBox() {
		return numberOfBox;
	}
	public void setNumberOfBox(String numberOfBox) {
		this.numberOfBox = numberOfBox;
	}
	public String getTheQuantityOfEachBox() {
		return theQuantityOfEachBox;
	}
	public void setTheQuantityOfEachBox(String theQuantityOfEachBox) {
		this.theQuantityOfEachBox = theQuantityOfEachBox;
	}
	public String getSavingTime() {
		return savingTime;
	}
	public void setSavingTime(String savingTime) {
		this.savingTime = savingTime;
	}
	public String getAcceptExpiry() {
		return acceptExpiry;
	}
	public void setAcceptExpiry(String acceptExpiry) {
		this.acceptExpiry = acceptExpiry;
	}
	
	public boolean isTransposted() {
		return transposted;
	}
	public void setTransposted(boolean transposted) {
		this.transposted = transposted;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
}
