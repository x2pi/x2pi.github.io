package com.fsoft.kohyoung.common.model;

import java.sql.Timestamp;

/**
 * @author DungTM8
 *
 */
public class MSoshikiDTO {

    private int soshikiKaisouFlg;

    private String soshikiCd;

    private String soshikiMei;

    private String oyaSoshikiCd;

    private String soshikiStatusCd;

    private int sortSeq;

    private long groupId;

    private Timestamp tourokuDt;

    private String tourokuUserid;

    private Timestamp koushinDt;

    private String koushinUserid;

    public int getSoshikiKaisouFlg() {
        return soshikiKaisouFlg;
    }

    public void setSoshikiKaisouFlg(int soshikiKaisouFlg) {
        this.soshikiKaisouFlg = soshikiKaisouFlg;
    }

    public String getSoshikiCd() {
        return soshikiCd;
    }

    public void setSoshikiCd(String soshikiCd) {
        this.soshikiCd = soshikiCd;
    }

    public String getSoshikiMei() {
        return soshikiMei;
    }

    public void setSoshikiMei(String soshikiMei) {
        this.soshikiMei = soshikiMei;
    }

    public String getOyaSoshikiCd() {
        return oyaSoshikiCd;
    }

    public void setOyaSoshikiCd(String oyaSoshikiCd) {
        this.oyaSoshikiCd = oyaSoshikiCd;
    }

    public String getSoshikiStatusCd() {
        return soshikiStatusCd;
    }

    public void setSoshikiStatusCd(String soshikiStatusCd) {
        this.soshikiStatusCd = soshikiStatusCd;
    }

    public int getSortSeq() {
        return sortSeq;
    }

    public void setSortSeq(int sortSeq) {
        this.sortSeq = sortSeq;
    }

    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(long groupId) {
        this.groupId = groupId;
    }

    public Timestamp getTourokuDt() {
        return tourokuDt;
    }

    public void setTourokuDt(Timestamp tourokuDt) {
        this.tourokuDt = tourokuDt;
    }

    public String getTourokuUserid() {
        return tourokuUserid;
    }

    public void setTourokuUserid(String tourokuUserid) {
        this.tourokuUserid = tourokuUserid;
    }

    public Timestamp getKoushinDt() {
        return koushinDt;
    }

    public void setKoushinDt(Timestamp koushinDt) {
        this.koushinDt = koushinDt;
    }

    public String getKoushinUserid() {
        return koushinUserid;
    }

    public void setKoushinUserid(String koushinUserid) {
        this.koushinUserid = koushinUserid;
    }
}
