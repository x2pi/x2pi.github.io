package com.fsoft.kohyoung.common.service;

import java.util.List;
import com.fsoft.kohyoung.common.entity.MBldg;

/**
 * @author DungTM8
 *
 */
public interface MBldgService {

    public List<MBldg> getLstBldg(String uselevel, String soshiki, long company);
}