package com.fsoft.kohyoung.common.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author DungTM8
 *
 */
@Entity
@Table(name="m_group")
public class MGroup {

    @Id
    @Column(name="group_id" , nullable = false)
    private String groupId;

    @Column(name="group_mei")
    private String groupMei;

    @Column(name="touroku_dt")
    private Timestamp tourokuDt;

    @Column(name="touroku_userid")
    private String tourokuUserid;

    @Column(name="koushin_dt")
    private Timestamp koushinDt;

    @Column(name="koushin_userid")
    private String koushinUserid;

    @Column(name="group_lat" , nullable= true)
    private int groupLat;

    @Column(name="group_lon", nullable = true)
    private int groupLon;

    @Column(name="icon_mei")
    private String iconMei;

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getGroupMei() {
        return groupMei;
    }

    public void setGroupMei(String groupMei) {
        this.groupMei = groupMei;
    }

    public Timestamp getTourokuDt() {
        return tourokuDt;
    }

    public void setTourokuDt(Timestamp tourokuDt) {
        this.tourokuDt = tourokuDt;
    }

    public String getTourokuUserid() {
        return tourokuUserid;
    }

    public void setTourokuUserid(String tourokuUserid) {
        this.tourokuUserid = tourokuUserid;
    }

    public Timestamp getKoushinDt() {
        return koushinDt;
    }

    public void setKoushinDt(Timestamp koushinDt) {
        this.koushinDt = koushinDt;
    }

    public String getKoushinUserid() {
        return koushinUserid;
    }

    public void setKoushinUserid(String koushinUserid) {
        this.koushinUserid = koushinUserid;
    }

    public double getGroupLat() {
        return groupLat;
    }

    public void setGroupLat(int groupLat) {
        this.groupLat = groupLat;
    }

    public double getGroupLon() {
        return groupLon;
    }

    public void setGroupLon(int groupLon) {
        this.groupLon = groupLon;
    }

    public String getIconMei() {
        return iconMei;
    }

    public void setIconMei(String iconMei) {
        this.iconMei = iconMei;
    }
}
