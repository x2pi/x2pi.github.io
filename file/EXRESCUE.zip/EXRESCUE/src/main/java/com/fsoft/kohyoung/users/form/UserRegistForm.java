package com.fsoft.kohyoung.users.form;

/**
 * Form for register user
 *
 * @author DungTM8
 */
public class UserRegistForm extends UserCommonForm{
		

}
