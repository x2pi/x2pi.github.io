package com.fsoft.kohyoung.damage;

import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Registry status of damage
 *
 * @author PhucPV
 */
@Controller
@RequestMapping("/damage/add")
public class DamageAddController {

    @ModelAttribute
    public DamageAddForm setupForm() {
	return new DamageAddForm();
    }

    @GetMapping
    public String index() {

	return "/damage/add";
    }

    @RequestMapping( method = RequestMethod.POST)
    public String addStudent(HttpServletRequest request, DamageAddForm damageAddForm, ModelMap model) {
	String action= request.getParameter("action");
	model.addAttribute("damageName", damageAddForm.getDamageName());

	//System.out.println(action);
	System.out.println(model.get("damageName"));
	//System.out.println(damageAddForm.getDamageName());

	if(action.equals("action1"))
	{
		System.out.println("hello1");

		return "redirect:/damage/info";
	}
	else if(action.equals("action2")) 
	{
		System.out.println("hello2");

		return "redirect:/damage";
	}
	return null;

    }
}
