package com.fsoft.kohyoung.damage;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fsoft.kohyoung.common.abstracts.BaseController;

/**
 * Registry status of damage by CSV
 *
 * @author PhucPV
 */
@Controller
@RequestMapping("/damage/registryCSV")
public class DamageRegistryCSV {
	
    @GetMapping
    public String index() {

        return "/damage/registryCSV";
    }

}
