package com.fsoft.kohyoung.damage;

import org.apache.catalina.servlet4preview.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fsoft.kohyoung.common.abstracts.BaseController;
import com.fsoft.kohyoung.common.entity.MGroup;
import com.fsoft.kohyoung.common.repository.MGroupRepository;

import java.sql.*;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;


/**
 * List Damage
 *
 * @author PhucPV
 */
@Controller
@RequestMapping("/damage")
public class DamageListController {

    
    
    @ModelAttribute
    public DamageSearchForm setupForm() {
	return new DamageSearchForm();
    }
	
    @GetMapping
    public String index() {
	
    	

        return "/damage/list";
    }
    

    @RequestMapping( method = RequestMethod.POST)
    public String addStudent(HttpServletRequest request, DamageSearchForm damageSearchForm, ModelMap model) {
	String action= request.getParameter("action");
	model.addAttribute("country", damageSearchForm.getCountry());

	if(action.equals("action1"))
	{
	    
		return "redirect:/damage/info";
	}
	else if(action.equals("action2")) 
	{

		return "redirect:/damage";
	}
	return null;

    }

    
    
    @ModelAttribute("countryList")
    public Map<String, String> getCountryList() {
       Map<String, String> countryList = new HashMap<String, String>();
       countryList.put("US", "United States");
       countryList.put("CH", "China");
       countryList.put("SG", "Singapore");
       countryList.put("MY", "Malaysia");
       return countryList;
    }
}
