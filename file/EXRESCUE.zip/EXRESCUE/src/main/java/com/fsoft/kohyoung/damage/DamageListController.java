package com.fsoft.kohyoung.damage;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fsoft.kohyoung.common.abstracts.BaseController;
import java.sql.*;


/**
 * List Damage
 *
 * @author PhucPV
 */
@Controller
@RequestMapping("/damage")
public class DamageListController {

	
    @GetMapping
    public String index() {
    	

        return "/damage/list";
    }

}
