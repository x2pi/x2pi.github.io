/**
 * 
 */
package com.fsoft.kohyoung.user.form;

/**
 * @author DungTM8
 *
 */
public class UserListForm {
	
	private String userName;
	
	private String userId;
	
	private String groupName;
	
	private String CompanyName;
	
	private String soshikiName;
	
	private String BuildingName;
	
	private String accountStat;

}
