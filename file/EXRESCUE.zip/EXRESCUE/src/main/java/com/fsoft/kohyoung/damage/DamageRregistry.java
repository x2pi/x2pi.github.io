package com.fsoft.kohyoung.damage;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fsoft.kohyoung.common.abstracts.BaseController;

/**
 * Registry status of damage
 *
 * @author PhucPV
 */
@Controller
@RequestMapping("/damage/registry")
public class DamageRregistry {
	
    @GetMapping
    public String index() {

        return "/damage/registry";
    }

}
