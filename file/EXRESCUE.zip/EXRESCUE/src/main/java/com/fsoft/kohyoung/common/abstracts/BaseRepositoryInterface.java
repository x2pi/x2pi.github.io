package com.fsoft.kohyoung.common.abstracts;

/**
 * io.cobrafw.iam.common.abstracts -> BaseRepositoryInterface
 *
 * @author duongnguyen
 * @since 1.0.0
 */
public interface BaseRepositoryInterface {

}
