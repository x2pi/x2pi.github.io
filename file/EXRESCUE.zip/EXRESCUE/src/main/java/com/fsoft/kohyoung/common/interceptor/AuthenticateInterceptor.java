package com.fsoft.kohyoung.common.interceptor;

/**
 * Authenticate interceptor
 *
 * @author duongnguyen
 */
public class AuthenticateInterceptor {

}
