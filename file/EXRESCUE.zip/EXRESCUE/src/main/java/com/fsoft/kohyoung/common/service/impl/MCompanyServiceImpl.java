package com.fsoft.kohyoung.common.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fsoft.kohyoung.common.abstracts.BaseService;
import com.fsoft.kohyoung.common.entity.MCompany;
import com.fsoft.kohyoung.common.repository.MCompanyRepository;
import com.fsoft.kohyoung.common.service.MCompanyService;

/**
 * @author DungTM8
 *
 */
@Service
public class MCompanyServiceImpl extends BaseService implements MCompanyService {

    @Autowired
    MCompanyRepository mCompanyRepository;

    @Override
    public List<MCompany> getLstCompany(String userLevel, String soshiki) {
        return mCompanyRepository.getLstCompany(userLevel, soshiki);
    }
}