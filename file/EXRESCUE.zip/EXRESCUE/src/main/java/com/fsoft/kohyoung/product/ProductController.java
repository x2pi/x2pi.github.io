package com.fsoft.kohyoung.product;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fsoft.kohyoung.common.abstracts.BaseController;

@Controller
@RequestMapping("/")
public class ProductController extends BaseController {

	@RequestMapping("/create")
	public String create(ModelMap model) {
		model.put("create", new ProductForm());
		return "products/create";
	}
	@RequestMapping("/detail")
	public String detail(){
		return "products/detail";
	}
	@RequestMapping("/update")
	public String update(ModelMap mm){
		mm.put("update", new ProductForm());
		return "products/update";
	}
}
