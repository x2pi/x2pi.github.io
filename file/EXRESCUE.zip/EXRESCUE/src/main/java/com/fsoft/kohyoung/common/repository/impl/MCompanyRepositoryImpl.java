package com.fsoft.kohyoung.common.repository.impl;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.fsoft.kohyoung.common.abstracts.BaseRepository;
import com.fsoft.kohyoung.common.entity.MCompany;
import com.fsoft.kohyoung.common.repository.MCompanyRepository;

/**
 * @author DungTM8
 *
 */
@Repository
public class MCompanyRepositoryImpl extends BaseRepository implements MCompanyRepository{

    @SuppressWarnings("unchecked")
    @Override
    public List<MCompany> getLstCompany(String userLevel, String soshiki) {
        List<MCompany> litCompany = new ArrayList<>();
        String query = "SELECT * FROM m_company cp ";
        litCompany = entityManager.createNativeQuery(query, MCompany.class).getResultList();
        return litCompany;
    }
}