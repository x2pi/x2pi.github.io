package com.fsoft.kohyoung.common.config;

import javax.persistence.EntityManagerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fsoft.kohyoung.common.sysdate.MySqlSysdateManagerImpl;
import com.fsoft.kohyoung.common.sysdate.SysdateManager;

/**
 * SysdateManagerConfig
 *
 * @author duongnguyen
 * @since 1.0.0
 */
@Configuration
public class SysdateManagerConfig {

    @Autowired
    private EntityManagerFactory entityManagerFactory;

    @Bean
    public SysdateManager sysdateManager() {
        return new MySqlSysdateManagerImpl(entityManagerFactory);
    }

}