/**
 * 
 */
package com.fsoft.kohyoung.user;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author DungTM8
 *
 */
@Controller
@RequestMapping("/user")
public class UserController {
	
    /**
     * Show login form
     *
     * @return Login input screen
     */
    @GetMapping
    public String input() {

        return "/users/list";
    }

    /**
     * Attempt login
     *
     * @return  Redirect to home page
     */
    @PostMapping
    public String submit() {

        return "redirect:/";
    }

}
