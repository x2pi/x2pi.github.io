package com.fsoft.kohyoung.users.form;

/**
 * Form for update user
 *
 * @author DungTM8
 */
public class UserUpdateForm extends UserCommonForm{

}
