package com.fsoft.kohyoung.common.repository;

import java.util.List;
import com.fsoft.kohyoung.common.entity.MCompany;

/**
 * @author DungTM8
 *
 */
public interface MCompanyRepository {

    public List<MCompany> getLstCompany(String userLevel, String soshiki);
}