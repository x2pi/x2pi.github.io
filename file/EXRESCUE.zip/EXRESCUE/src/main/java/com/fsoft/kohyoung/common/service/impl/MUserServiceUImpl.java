package com.fsoft.kohyoung.common.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fsoft.kohyoung.common.abstracts.BaseService;
import com.fsoft.kohyoung.common.model.MUserDTO;
import com.fsoft.kohyoung.common.repository.MUserRepository;
import com.fsoft.kohyoung.common.service.MUserService;

/**
 * MUser Service Implement
 * 
 * @author DungTM8
 */
@Service
public class MUserServiceUImpl extends BaseService implements MUserService{

    /** mUser Repository */
    @Autowired
    MUserRepository mUserRepository ;

    @Override
    public Long inserUser(MUserDTO userDto) {
        return mUserRepository.inserUser(userDto);
    }
}