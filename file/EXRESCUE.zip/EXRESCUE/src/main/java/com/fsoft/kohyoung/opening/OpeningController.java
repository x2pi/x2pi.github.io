package com.fsoft.kohyoung.opening;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fsoft.kohyoung.common.abstracts.BaseController;

/**
 * Opening controller
 *
 * @author duongnguyen
 */
@Controller
@RequestMapping("/")
public class OpeningController  extends BaseController {

    /**
     * Show opening screen
     *
     * @return Opening screen
     */
    @GetMapping
    public String index() {

        return "/opening/index";
    }
}
