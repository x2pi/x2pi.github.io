package com.fsoft.kohyoung.common.repository.impl;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.fsoft.kohyoung.common.abstracts.BaseRepository;
import com.fsoft.kohyoung.common.entity.MHanyou;
import com.fsoft.kohyoung.common.repository.MHanyouRepository;

/**
 * MHanyou Repository Implement
 * 
 * @author DungTM8
 */
@Repository
public class MHanyouRepositoryImpl extends BaseRepository implements MHanyouRepository {

    @SuppressWarnings("unchecked")
    @Override
    public List<MHanyou> selectLstBunruiCd(String param) {
        List<MHanyou> lstMHanyou = new ArrayList<>();
        String query = "SELECT * FROM m_hanyou hy where hy.hanyou_bunrui_cd = ?1";
        lstMHanyou = entityManager.createNativeQuery(query, MHanyou.class).setParameter(1, param).getResultList();
        return lstMHanyou;
    }
}