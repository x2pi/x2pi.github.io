package com.fsoft.kohyoung.common.sysdate;

import java.util.Date;

import javax.persistence.EntityManagerFactory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.NativeQuery;

/**
 * io.cobrafw.sysdate.impl -> MySqlSysdateManagerImpl
 *
 * @author duongnguyen
 * @since 1.0.0
 */
public class MySqlSysdateManagerImpl implements SysdateManager {


    /*================================================================================================================
     *===== STATIC PROPERTIES                                                                                    =====
     *================================================================================================================*/

    /** Thread local sysdate holder */
    private static final ThreadLocal<Date> threadLocalSysDateHolder = new ThreadLocal();

    /*================================================================================================================
     *===== PRIVATE PROPERTIES                                                                                   =====
     *================================================================================================================*/

    /**
     * Base date time - Start date time of java server
     */
    private Date baseDateTime;

    /**
     * Calculate date time - Get from database
     */
    private Date calculateDateTime;

    /**
     * The deviation between DB date and java date
     */
    private long deviation;



    /*================================================================================================================
     *===== CONSTRUCTOR METHOD                                                                                   =====
     *================================================================================================================*/

    /**
     * Constructor with entity manager
     *
     * @param entityManagerFactory JPA Entity Manager Factory
     */
    public MySqlSysdateManagerImpl(EntityManagerFactory entityManagerFactory) {

        // Get DB sysdate
        Session session = entityManagerFactory.unwrap(SessionFactory.class).openSession();
        String queryString = "SELECT NOW() AS SYSDATE";
        NativeQuery nativeQuery = session.createNativeQuery(queryString);
        nativeQuery.addScalar("SYSDATE");
        baseDateTime = (Date) nativeQuery.uniqueResult();
        session.close();

        // Get java sysdate
        calculateDateTime = new Date();

        // Set deviation between Java sysdate and DB sysdate
        deviation = calculateDateTime.getTime() - baseDateTime.getTime();
    }

    /*================================================================================================================
     *===== IMPLEMENTATION METHOD                                                                                =====
     *================================================================================================================*/

    /**
     * Get current sysdate
     *
     * @return Current sysdate
     */
    @Override
    public Date getCurrentSysDate() {

        // Get current time and plus with deviation
        long currentTime = new Date().getTime() + deviation;

        // Convert time to date and return it
        return new Date(currentTime);
    }

    /**
     * Get sysdate in local thread
     *
     * @return Thread local sysdate
     */
    @Override
    public Date getThreadLocalSysDate() {

        // Return local thread sysdate
        Date sysdate = threadLocalSysDateHolder.get();

        // In case, local thread sysdate wasn't set before,
        // get current sysdate and set into it
        if (sysdate == null) {
            sysdate = getCurrentSysDate();
            threadLocalSysDateHolder.set(sysdate);
        }

        // Return sysdate
        return sysdate;
    }

    /**
     * Get sysdate in local thread
     *
     * @return Thread local sysdate
     */
    @Override
    public void setThreadLocalSysDate() {

        // Set local thread sysdate
        threadLocalSysDateHolder.set(getCurrentSysDate());
    }
}
