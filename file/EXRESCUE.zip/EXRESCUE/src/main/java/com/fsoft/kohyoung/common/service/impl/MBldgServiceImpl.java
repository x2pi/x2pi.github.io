package com.fsoft.kohyoung.common.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fsoft.kohyoung.common.abstracts.BaseService;
import com.fsoft.kohyoung.common.entity.MBldg;
import com.fsoft.kohyoung.common.repository.MBldgRepository;
import com.fsoft.kohyoung.common.service.MBldgService;

/**
 * @author DungTM8
 *
 */
@Service
public class MBldgServiceImpl extends BaseService implements MBldgService {

    @Autowired
    MBldgRepository mBldgRepository;

    @Override
    public List<MBldg> getLstBldg(String uselevel, String soshiki, long company) {
        return mBldgRepository.getLstBldg(uselevel, soshiki, company);
    }
}