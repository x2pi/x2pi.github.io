package com.fsoft.kohyoung.users.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.fsoft.kohyoung.common.abstracts.BaseController;
import com.fsoft.kohyoung.common.entity.MBldg;
import com.fsoft.kohyoung.common.entity.MCompany;
import com.fsoft.kohyoung.common.entity.MGroup;
import com.fsoft.kohyoung.common.entity.MHanyou;
import com.fsoft.kohyoung.common.entity.MSoshiki;
import com.fsoft.kohyoung.common.service.MBldgService;
import com.fsoft.kohyoung.common.service.MCompanyService;
import com.fsoft.kohyoung.common.service.MGroupService;
import com.fsoft.kohyoung.common.service.MHanyouService;
import com.fsoft.kohyoung.common.service.MSoshikiService;
import com.fsoft.kohyoung.common.service.MUserService;
import com.fsoft.kohyoung.users.form.UserRegistForm;

/**
 * Register user controller
 *
 * @author DungTM8
 */
@RequestMapping({"users/regist"})
@Controller
public class RegistUserController extends BaseController{

    /*============================== PROPERTIES =============================*/
    @Autowired
    MUserService mUserService;

    @Autowired
    MGroupService mGroupService;

    @Autowired
    MSoshikiService mSoshikiService;

    @Autowired
    MCompanyService mCompanyService;

    @Autowired
    MBldgService mBldgService;

    @Autowired
    private MHanyouService mHanyouService;

    /*============================== METHOD =================================*/
    @ModelAttribute
    public UserRegistForm setupForm() {
        return new UserRegistForm();
    }

    /**
     * Register User Screen
     *
     * @return Register user screen
     */    
    @RequestMapping()
    public String index(UserRegistForm form, Model model) {

        setPulldown(form, model);
        return "users/regist";
    }

    /**
     * @param form UserRegistForm
     * @param model
     */
    private void setPulldown(UserRegistForm form, Model model) {

        // get list Group
        List<MGroup> mGroups = mGroupService.getLstGroup("");

        // get list Soshiki
        List<MSoshiki> mSoshikis = mSoshikiService.getLstSoshiki("", 0);

        // get sist Company
        List<MCompany> mCompanies = mCompanyService.getLstCompany("", "");

        // get list Building
        List<MBldg> mBldgs = mBldgService.getLstBldg("", "", 0);

        // get list hanyou
        List<MHanyou> listHanyou = mHanyouService.selectLstBunruiCd("9001");
        // 
        model.addAttribute("groupList", mGroups);
        model.addAttribute("soshikiList", mSoshikis);
        model.addAttribute("companyList", mCompanies);
        model.addAttribute("bldgList", mBldgs);
        model.addAttribute("item04CdList", listHanyou);
    }

    /**
     * Insert DB
     * 
     */
    @RequestMapping(value = { "insert" }, method = RequestMethod.POST)
    public String insert(UserRegistForm form,  BindingResult result, Model model) {

        Validate(form, result);
        return "users/regist";
    }

    /**
     * Validation form
     */
    private void Validate(UserRegistForm form, BindingResult result) {

        // UserId
        if (StringUtils.isEmpty(form.getUserid())) {
            result.rejectValue("userid", "msg.error.user.userid");
        }

        // UserMei
        if(StringUtils.isEmpty(form.getUsermei())) {
            result.rejectValue("usermei", "msg.error.user.usermei");
        }

        // Password
        if(StringUtils.isEmpty(form.getPassword())) {
            result.rejectValue("password", "msg.error.user.password");
        }

        if(StringUtils.isEmpty(form.getConfirmPassword())) {
            result.rejectValue("confirmPassword",  "msg.error.user.confirmPassword");
        }

        // Group
        if (form.getGroupId() == null) {
            result.rejectValue("groupId", "msg.error.user.groupId");
        }
    }
}