package com.fsoft.kohyoung.common.model;

import java.sql.Timestamp;

/**
 * MUserDTO
 * 
 * @author DungTM8
 */
public class MUserDTO {

    private int id;

    private String userID;

    private String password;

    private String passwordUpdate;

    private String before1Password;

    private String before2Password;

    private String userMei;

    private String authGroupCd;

    private String telNo;

    private String soshiki1Cd;

    private String soshiki2Cd;

    private String soshiki3Cd;

    private String soshiki4Cd;

    private String soshiki5Cd;

    private String soshiki6Cd;

    private String soshikiNM;

    private String item01Cd;

    private String item02Cd;

    private String item03Cd;

    private String item04Cd;

    private String item05Cd;

    private String item01Txt;

    private String item02Txt;

    private String item03Txt;

    private String item04Txt;

    private String item05Txt;

    private Timestamp tourokuDt;

    private String tourokuUserId;

    private Timestamp koushinDt;

    private String koushinUserId;

    private int delFlg;

    private Timestamp delDt;

    private String delUserID;

    private String soshiki7Cd;

    private String soshiki8Cd;

    private String soshiki9Cd;

    private String soshiki10Cd;

    public int getid() {
        return id;
    }

    public void setid(int id) {
        this.id = id;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPasswordUpdate() {
        return passwordUpdate;
    }

    public void setPasswordUpdate(String passwordUpdate) {
        this.passwordUpdate = passwordUpdate;
    }

    public String getBefore1Password() {
        return before1Password;
    }

    public void setBefore1Password(String before1Password) {
        this.before1Password = before1Password;
    }

    public String getBefore2Password() {
        return before2Password;
    }

    public void setBefore2Password(String before2Password) {
        this.before2Password = before2Password;
    }

    public String getUserMei() {
        return userMei;
    }

    public void setUserMei(String userMei) {
        this.userMei = userMei;
    }

    public String getAuthGroupCd() {
        return authGroupCd;
    }

    public void setAuthGroupCd(String authGroupCd) {
        this.authGroupCd = authGroupCd;
    }

    public String getTelNo() {
        return telNo;
    }

    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    public String getSoshiki1Cd() {
        return soshiki1Cd;
    }

    public void setSoshiki1Cd(String soshiki1Cd) {
        this.soshiki1Cd = soshiki1Cd;
    }

    public String getSoshiki2Cd() {
        return soshiki2Cd;
    }

    public void setSoshiki2Cd(String soshiki2Cd) {
        this.soshiki2Cd = soshiki2Cd;
    }

    public String getSoshiki3Cd() {
        return soshiki3Cd;
    }

    public void setSoshiki3Cd(String soshiki3Cd) {
        this.soshiki3Cd = soshiki3Cd;
    }

    public String getSoshiki4Cd() {
        return soshiki4Cd;
    }

    public void setSoshiki4Cd(String soshiki4Cd) {
        this.soshiki4Cd = soshiki4Cd;
    }

    public String getSoshiki5Cd() {
        return soshiki5Cd;
    }

    public void setSoshiki5Cd(String soshiki5Cd) {
        this.soshiki5Cd = soshiki5Cd;
    }

    public String getSoshiki6Cd() {
        return soshiki6Cd;
    }

    public void setSoshiki6Cd(String soshiki6Cd) {
        this.soshiki6Cd = soshiki6Cd;
    }

    public String getSoshikiNM() {
        return soshikiNM;
    }

    public void setSoshikiNM(String soshikiNM) {
        this.soshikiNM = soshikiNM;
    }

    public String getItem01Cd() {
        return item01Cd;
    }

    public void setItem01Cd(String item01Cd) {
        this.item01Cd = item01Cd;
    }

    public String getItem02Cd() {
        return item02Cd;
    }

    public void setItem02Cd(String item02Cd) {
        this.item02Cd = item02Cd;
    }

    public String getItem03Cd() {
        return item03Cd;
    }

    public void setItem03Cd(String item03Cd) {
        this.item03Cd = item03Cd;
    }

    public String getItem04Cd() {
        return item04Cd;
    }

    public void setItem04Cd(String item04Cd) {
        this.item04Cd = item04Cd;
    }

    public String getItem05Cd() {
        return item05Cd;
    }

    public void setItem05Cd(String item05Cd) {
        this.item05Cd = item05Cd;
    }

    public String getItem01Txt() {
        return item01Txt;
    }

    public void setItem01Txt(String item01Txt) {
        this.item01Txt = item01Txt;
    }

    public String getItem02Txt() {
        return item02Txt;
    }

    public void setItem02Txt(String item02Txt) {
        this.item02Txt = item02Txt;
    }

    public String getItem03Txt() {
        return item03Txt;
    }

    public void setItem03Txt(String item03Txt) {
        this.item03Txt = item03Txt;
    }

    public String getItem04Txt() {
        return item04Txt;
    }

    public void setItem04Txt(String item04Txt) {
        this.item04Txt = item04Txt;
    }

    public String getItem05Txt() {
        return item05Txt;
    }

    public void setItem05Txt(String item05Txt) {
        this.item05Txt = item05Txt;
    }

    public Timestamp getTourokuDt() {
        return tourokuDt;
    }

    public void setTourokuDt(Timestamp tourokuDt) {
        this.tourokuDt = tourokuDt;
    }

    public String getTourokuUserId() {
        return tourokuUserId;
    }

    public void setTourokuUserId(String tourokuUserId) {
        this.tourokuUserId = tourokuUserId;
    }

    public Timestamp getKoushinDt() {
        return koushinDt;
    }

    public void setKoushinDt(Timestamp koushinDt) {
        this.koushinDt = koushinDt;
    }

    public String getKoushinUserId() {
        return koushinUserId;
    }

    public void setKoushinUserId(String koushinUserId) {
        this.koushinUserId = koushinUserId;
    }

    public int getDelFlg() {
        return delFlg;
    }

    public void setDelFlg(int delFlg) {
        this.delFlg = delFlg;
    }

    public Timestamp getDelDt() {
        return delDt;
    }

    public void setDelDt(Timestamp delDt) {
        this.delDt = delDt;
    }

    public String getDelUserID() {
        return delUserID;
    }

    public void setDelUserID(String delUserID) {
        this.delUserID = delUserID;
    }

    public String getSoshiki7Cd() {
        return soshiki7Cd;
    }

    public void setSoshiki7Cd(String soshiki7Cd) {
        this.soshiki7Cd = soshiki7Cd;
    }

    public String getSoshiki8Cd() {
        return soshiki8Cd;
    }

    public void setSoshiki8Cd(String soshiki8Cd) {
        this.soshiki8Cd = soshiki8Cd;
    }

    public String getSoshiki9Cd() {
        return soshiki9Cd;
    }

    public void setSoshiki9Cd(String soshiki9Cd) {
        this.soshiki9Cd = soshiki9Cd;
    }

    public String getSoshiki10Cd() {
        return soshiki10Cd;
    }

    public void setSoshiki10Cd(String soshiki10Cd) {
        this.soshiki10Cd = soshiki10Cd;
    }
}
