package com.fsoft.kohyoung.users.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.fsoft.kohyoung.common.abstracts.BaseController;
import com.fsoft.kohyoung.users.form.UserListForm;

/**
 * List user controller
 *
 * @author duongnguyen
 */
@Controller
@RequestMapping("/users/list")
public class ListUserController extends BaseController {

    /*================================ PROPERTIES ====================================*/

    /*================================= METHOD =======================================*/
    @ModelAttribute
    public UserListForm setupForm() {
        return new UserListForm();
    }

    /**
     * List User Screen
     *
     * @return List user Screen
     */
    @RequestMapping()
    public String index(UserListForm form, Model model) {

        return "users/list";
    }

    /**
     * @return Result search of user Screen
     */
    @RequestMapping(value = { "search" }, method = RequestMethod.POST)
    public String search(Model model) {
        return "/users/regist";
    }
}
