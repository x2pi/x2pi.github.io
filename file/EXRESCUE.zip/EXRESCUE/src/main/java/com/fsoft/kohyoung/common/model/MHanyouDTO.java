package com.fsoft.kohyoung.common.model;

import java.sql.Timestamp;


/**
 * @author DungTM8
 *
 */
public class MHanyouDTO {

    private String hanyouBunruiCd;

    private String hanyouCd;

    private String hanyouBunruiMei;

    private String hanyouCdValue;

    private Integer hanyouCdSort;

    private String hanyouCd1byte;

    private String hanyouBikou;

    private String kanrenCd;

    private Timestamp tourokuDt;

    private Timestamp koushinDt;

    public String getHanyouBunruiCd() {
        return hanyouBunruiCd;
    }

    public void setHanyouBunruiCd(String hanyouBunruiCd) {
        this.hanyouBunruiCd = hanyouBunruiCd;
    }

    public String getHanyouCd() {
        return hanyouCd;
    }

    public void setHanyouCd(String hanyouCd) {
        this.hanyouCd = hanyouCd;
    }

    public String getHanyouBunruiMei() {
        return hanyouBunruiMei;
    }

    public void setHanyouBunruiMei(String hanyouBunruiMei) {
        this.hanyouBunruiMei = hanyouBunruiMei;
    }

    public String getHanyouCdValue() {
        return hanyouCdValue;
    }

    public void setHanyouCdValue(String hanyouCdValue) {
        this.hanyouCdValue = hanyouCdValue;
    }

    public Integer getHanyouCdSort() {
        return hanyouCdSort;
    }

    public void setHanyouCdSort(Integer hanyouCdSort) {
        this.hanyouCdSort = hanyouCdSort;
    }

    public String getHanyouCd1byte() {
        return hanyouCd1byte;
    }

    public void setHanyouCd1byte(String hanyouCd1byte) {
        this.hanyouCd1byte = hanyouCd1byte;
    }

    public String getHanyouBikou() {
        return hanyouBikou;
    }

    public void setHanyouBikou(String hanyouBikou) {
        this.hanyouBikou = hanyouBikou;
    }

    public String getKanrenCd() {
        return kanrenCd;
    }

    public void setKanrenCd(String kanrenCd) {
        this.kanrenCd = kanrenCd;
    }

    public Timestamp getTourokuDt() {
        return tourokuDt;
    }

    public void setTourokuDt(Timestamp tourokuDt) {
        this.tourokuDt = tourokuDt;
    }

    public Timestamp getKoushinDt() {
        return koushinDt;
    }

    public void setKoushinDt(Timestamp koushinDt) {
        this.koushinDt = koushinDt;
    }

}