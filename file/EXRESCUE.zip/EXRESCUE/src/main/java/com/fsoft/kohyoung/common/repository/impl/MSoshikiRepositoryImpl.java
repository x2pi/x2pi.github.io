package com.fsoft.kohyoung.common.repository.impl;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.fsoft.kohyoung.common.abstracts.BaseRepository;
import com.fsoft.kohyoung.common.entity.MSoshiki;
import com.fsoft.kohyoung.common.repository.MSoshikiRepository;

/**
 * @author DungTM8
 *
 */
@Repository
public class MSoshikiRepositoryImpl extends BaseRepository implements MSoshikiRepository {

    @SuppressWarnings("unchecked")
    @Override
    public List<MSoshiki> getLstSoshiki(String useLevel, long groupId) {
        List<MSoshiki> lstShoshiki = new ArrayList<>();
        String query = "SELECT * FROM m_soshiki sh ";
        lstShoshiki = entityManager.createNativeQuery(query, MSoshiki.class).getResultList();
        return lstShoshiki;
    }
}