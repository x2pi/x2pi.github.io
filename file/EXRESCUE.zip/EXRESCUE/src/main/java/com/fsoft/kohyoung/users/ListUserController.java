package com.fsoft.kohyoung.users;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * List user controller
 *
 * @author duongnguyen
 */
@Controller
@RequestMapping("/users")
public class ListUserController {

    /**
     * Show list user screen
     *
     * @return List user
     */
    @GetMapping
    public String index(ModelMap model) {

        return "users/list";
    }
}
