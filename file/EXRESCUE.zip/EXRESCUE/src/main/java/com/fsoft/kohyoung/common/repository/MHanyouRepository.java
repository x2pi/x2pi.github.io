package com.fsoft.kohyoung.common.repository;

import java.util.List;
import com.fsoft.kohyoung.common.entity.MHanyou;

/**
 * MHanyou Repository
 * 
 * @author DungTM8
 */
public interface MHanyouRepository {

    /**
    * Get List MHanyou
    *
    * @return List of MHanyou
    */
    public List<MHanyou> selectLstBunruiCd(String param);
}