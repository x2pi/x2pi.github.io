package com.fsoft.kohyoung.common.sysdate;

import java.util.Date;

/**
 * io.cobrafw.sysdate -> SysdateManager
 *
 * @author duongnguyen
 * @since 1.0.0
 */
public interface SysdateManager {

    /**
     * Get current sysdate
     *
     * @return Current sysdate
     */
    Date getCurrentSysDate();

    /**
     * Get sysdate in local thread
     *
     * @return Thread local sysdate
     */
    Date getThreadLocalSysDate();

    /**
     * Get sysdate in local thread
     *
     * @return Thread local sysdate
     */
    void setThreadLocalSysDate();
}
