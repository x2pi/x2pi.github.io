package com.fsoft.kohyoung.damage;

public class DamageAddForm {
    
    
    private String damageName;
    private String groupName;
    private String companyName;
    private String organizationName;
    private String buildingName;
    private String countReports;

    
    public void setDamageName(String damageName) {
	this.damageName = damageName;
    }

    public String getDamageName() {
	return damageName;
    }

    public String getCountReports() {
	return countReports;
    }

    public void setCountReports(String countReports) {
	this.countReports = countReports;
    }

    public String getGroupName() {
	return groupName;
    }

    public void setGroupName(String groupName) {
	this.groupName = groupName;
    }

    public String getCompanyName() {
	return companyName;
    }

    public void setCompanyName(String companyName) {
	this.companyName = companyName;
    }

    public String getOrganizationName() {
	return organizationName;
    }

    public void setOrganizationName(String organizationName) {
	this.organizationName = organizationName;
    }

    public String getBuildingName() {
	return buildingName;
    }

    public void setBuildingName(String buildingName) {
	this.buildingName = buildingName;
    }

}
