package com.fsoft.kohyoung.users.form;

/**
 * Common form for function User
 *
 * @author DungTM8
 */
public class UserCommonForm {
	
	protected String groupId;	

	protected String userid;

	private String detailUserid;

	protected String password;

	protected String confirmPassword;

	protected String usermei;

	protected String authGroupCd;

	protected String tsuuhousyaBunruiCd;

	protected String shokuinLevelCd;

	protected String smartPhoneCd;

	protected String mailAddress;

	protected String featurePhoneCd;

	protected String featurePhoneMailAddress;

	protected String soshiki1Cd;

	protected String soshiki2Cd;

	protected String soshiki3Cd;

	protected String soshiki4Cd;

	protected String soshiki5Cd;

	protected String soshiki6Cd;
	
	protected String soshiki7Cd;
	
	protected String soshiki8Cd;
	
	protected String soshiki9Cd;
	
	protected String soshiki10Cd;

	protected String soshikiNm;

	protected String telNo;

	protected String item01Cd;

	protected String item02Cd;

	protected String item03Cd;

	protected String item04Cd;

	protected String item05Cd;

	protected String item01Txt;

	protected String item02Txt;

	protected String item03Txt;

	protected String item04Txt;

	protected String item05Txt;

	public void setItem05Txt(String item05Txt) {
		this.item05Txt = item05Txt;
	}

	public void setItem04Txt(String item04Txt) {
		this.item04Txt = item04Txt;
	}

	public void setItem03Txt(String item03Txt) {
		this.item03Txt = item03Txt;
	}

	public void setItem02Txt(String item02Txt) {
		this.item02Txt = item02Txt;
	}

	public void setItem01Txt(String item01Txt) {
		this.item01Txt = item01Txt;
	}

	public void setItem05Cd(String item05Cd) {
		this.item05Cd = item05Cd;
	}

	public void setItem04Cd(String item04Cd) {
		this.item04Cd = item04Cd;
	}

	public void setItem03Cd(String item03Cd) {
		this.item03Cd = item03Cd;
	}

	public void setItem02Cd(String item02Cd) {
		this.item02Cd = item02Cd;
	}

	public void setItem01Cd(String item01Cd) {
		this.item01Cd = item01Cd;
	}

	public void setTelNo(String telNo) {
		this.telNo = telNo;
	}

	public void setSoshikiNm(String soshikiNm) {
		this.soshikiNm = soshikiNm;
	}

	public void setSoshiki6Cd(String soshiki6Cd) {
		this.soshiki6Cd = soshiki6Cd;
	}

	public void setSoshiki5Cd(String soshiki5Cd) {
		this.soshiki5Cd = soshiki5Cd;
	}

	public void setSoshiki4Cd(String soshiki4Cd) {
		this.soshiki4Cd = soshiki4Cd;
	}

	public void setSoshiki3Cd(String soshiki3Cd) {
		this.soshiki3Cd = soshiki3Cd;
	}

	public void setSoshiki2Cd(String soshiki2Cd) {
		this.soshiki2Cd = soshiki2Cd;
	}

	public void setSoshiki1Cd(String soshiki1Cd) {
		this.soshiki1Cd = soshiki1Cd;
	}

	public void setFeaturePhoneMailAddress(String featurePhoneMailAddress) {
		this.featurePhoneMailAddress = featurePhoneMailAddress;
	}

	public void setFeaturePhoneCd(String featurePhoneCd) {
		this.featurePhoneCd = featurePhoneCd;
	}

	public void setMailAddress(String mailAddress) {
		this.mailAddress = mailAddress;
	}

	public void setSmartPhoneCd(String smartPhoneCd) {
		this.smartPhoneCd = smartPhoneCd;
	}

	public void setShokuinLevelCd(String shokuinLevelCd) {
		this.shokuinLevelCd = shokuinLevelCd;
	}

	public void setTsuuhousyaBunruiCd(String tsuuhousyaBunruiCd) {
		this.tsuuhousyaBunruiCd = tsuuhousyaBunruiCd;
	}

	public void setAuthGroupCd(String authGroupCd) {
		this.authGroupCd = authGroupCd;
	}

	public void setUsermei(String usermei) {
		this.usermei = usermei;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setDetailUserid(String detailUserid) {
		this.detailUserid = detailUserid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getItem05Txt() {
		return this.item05Txt;
	}

	public String getItem04Txt() {
		return this.item04Txt;
	}

	public String getItem03Txt() {
		return this.item03Txt;
	}

	public String getItem02Txt() {
		return this.item02Txt;
	}

	public String getItem01Txt() {
		return this.item01Txt;
	}

	public String getItem05Cd() {
		return this.item05Cd;
	}

	public String getItem04Cd() {
		return this.item04Cd;
	}

	public String getItem03Cd() {
		return this.item03Cd;
	}

	public String getItem02Cd() {
		return this.item02Cd;
	}

	public String getItem01Cd() {
		return this.item01Cd;
	}

	public String getTelNo() {
		return this.telNo;
	}

	public String getSoshikiNm() {
		return this.soshikiNm;
	}

	public String getSoshiki6Cd() {
		return this.soshiki6Cd;
	}

	public String getSoshiki5Cd() {
		return this.soshiki5Cd;
	}

	public String getSoshiki4Cd() {
		return this.soshiki4Cd;
	}

	public String getSoshiki3Cd() {
		return this.soshiki3Cd;
	}

	public String getSoshiki2Cd() {
		return this.soshiki2Cd;
	}

	public String getSoshiki1Cd() {
		return this.soshiki1Cd;
	}

	public String getFeaturePhoneMailAddress() {
		return this.featurePhoneMailAddress;
	}

	public String getFeaturePhoneCd() {
		return this.featurePhoneCd;
	}

	public String getMailAddress() {
		return this.mailAddress;
	}

	public String getSmartPhoneCd() {
		return this.smartPhoneCd;
	}

	public String getShokuinLevelCd() {
		return this.shokuinLevelCd;
	}

	public String getTsuuhousyaBunruiCd() {
		return this.tsuuhousyaBunruiCd;
	}

	public String getAuthGroupCd() {
		return this.authGroupCd;
	}

	public String getUsermei() {
		return this.usermei;
	}

	public String getConfirmPassword() {
		return this.confirmPassword;
	}

	public String getPassword() {
		return this.password;
	}

	public String getDetailUserid() {
		return this.detailUserid;
	}

	public String getUserid() {
		return this.userid;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getSoshiki7Cd() {
		return soshiki7Cd;
	}

	public void setSoshiki7Cd(String soshiki7Cd) {
		this.soshiki7Cd = soshiki7Cd;
	}

	public String getSoshiki8Cd() {
		return soshiki8Cd;
	}

	public void setSoshiki8Cd(String soshiki8Cd) {
		this.soshiki8Cd = soshiki8Cd;
	}

	public String getSoshiki9Cd() {
		return soshiki9Cd;
	}

	public void setSoshiki9Cd(String soshiki9Cd) {
		this.soshiki9Cd = soshiki9Cd;
	}

	public String getSoshiki10Cd() {
		return soshiki10Cd;
	}

	public void setSoshiki10Cd(String soshiki10Cd) {
		this.soshiki10Cd = soshiki10Cd;
	}
}
