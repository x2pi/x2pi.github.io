package com.fsoft.kohyoung.users.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fsoft.kohyoung.common.abstracts.BaseController;
import com.fsoft.kohyoung.users.form.UserUpdateForm;

/**
 * @author DungTM8
 *
 */
@RequestMapping({ "users/update" })
@Controller
public class UpdateUserController extends BaseController {

    @ModelAttribute
    public UserUpdateForm setupForm() {
        return new UserUpdateForm();
    }

    /**
     * Update User Screen
     *
     * @return Update user screen
     */
    @RequestMapping()
    public String index(UserUpdateForm form, Model model) {
        return "users/update";
    }
}
