package com.fsoft.kohyoung.common.repository;

import com.fsoft.kohyoung.common.model.MUserDTO;

/**
 * MUser Repository
 * 
 * @author DungTM8
 */
public interface MUserRepository {

    /**
     * Insert User
     *
     * @return index of result insert
     */
    public Long inserUser(MUserDTO userDto);
}