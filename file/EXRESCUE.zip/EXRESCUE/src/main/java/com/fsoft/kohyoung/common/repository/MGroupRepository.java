package com.fsoft.kohyoung.common.repository;

import java.util.List;
import com.fsoft.kohyoung.common.entity.MGroup;

/**
 * MGroup Repository
 * 
 * @author DungTM8
 */
public interface MGroupRepository {

    public List<MGroup> getLstGroup(String levelUser);
}