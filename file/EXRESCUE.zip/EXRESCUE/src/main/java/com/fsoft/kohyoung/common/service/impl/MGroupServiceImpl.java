package com.fsoft.kohyoung.common.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fsoft.kohyoung.common.abstracts.BaseService;
import com.fsoft.kohyoung.common.entity.MGroup;
import com.fsoft.kohyoung.common.repository.MGroupRepository;
import com.fsoft.kohyoung.common.service.MGroupService;

/**
 * MGroup Service Implement
 * 
 * @author DungTM8
 */
@Service
public class MGroupServiceImpl extends BaseService implements MGroupService {

    @Autowired
    MGroupRepository mGroupRepository;

    @Override
    public List<MGroup> getLstGroup(String levelUser) {
        return mGroupRepository.getLstGroup(levelUser);
    }
}