package com.fsoft.kohyoung.common.service;

import com.fsoft.kohyoung.common.model.MUserDTO;

/**
 * MUser Service
 * 
 * @author DungTM8
 */
public interface MUserService {

    public abstract Long inserUser(MUserDTO userDTO) ;
}