package com.fsoft.kohyoung.damage;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fsoft.kohyoung.common.abstracts.BaseController;

/**
 * Info Damage
 *
 * @author PhucPV
 */
@Controller
@RequestMapping("/damage/info")
public class DamageInfo {
	
    @GetMapping
    public String index() {

        return "/damage/info";
    }

}
