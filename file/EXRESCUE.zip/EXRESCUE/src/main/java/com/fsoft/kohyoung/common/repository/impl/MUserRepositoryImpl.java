package com.fsoft.kohyoung.common.repository.impl;

import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.fsoft.kohyoung.common.abstracts.BaseRepository;
import com.fsoft.kohyoung.common.model.MUserDTO;
import com.fsoft.kohyoung.common.repository.MUserRepository;

/**
 * MUser Repository Implement
 * 
 * @author DungTM8
 */
@Repository
public class MUserRepositoryImpl extends BaseRepository implements MUserRepository{

    @Override
    public Long inserUser(MUserDTO userDto) {

        String sql = "INSERT INTO m_user(id, userid, password, password_update,"
                + "before1_password, before2_password, usermei, auth_group_cd, tel_no"
                + "soshiki_1_cd, soshiki_2_cd, soshiki_3_cd, soshiki_4_cd, soshiki_5_cd, soshiki_6_cd"
                + "soshiki_nm, item_01_cd, item_02_cd, item_03_cd, item_04_cd, item_05_cd, item_01_txt,"
                + "item_02_txt, item_03_txt, item_04_txt, item_05_txt, touroku_dt, touroku_userid, koushin_dt,"
                + "koushin_userid, del_flg, del_dt, del_userid, soshiki_7_cd, soshiki_8_cd, soshiki_9_cd, soshiki_10_cd ) "
                + "VALUES ("
                + ":id, :userID, :password, :passwordUpdate, :before1Password, :before2Password, :userMei, :authGroupCd, :telNo, "
                + ":soshiki1Cd, :soshiki2Cd,  :soshiki3Cd,  :soshiki4Cd,  :soshiki5Cd,  :soshiki6Cd, "
                + ":soshikiNM, :item01Cd, :item02Cd, :item03Cd, :item04Cd, :item05Cd, :item01Txt, "
                + ":item02Txt, :item03Txt, :item04Txt, :item05Txt, :tourokuDt, :tourokuUserId, :koushinDt, "
                + ":koushinUserId, :delFlg, :delDt, :delUserID, :soshiki7Cd, :soshiki8Cd, :soshiki9Cd, :soshiki10Cd )";

        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("id", userDto.getid());
        query.setParameter("userID", userDto.getUserID());
        query.setParameter("password", userDto.getPassword());
        query.setParameter("passwordUpdate", userDto.getPasswordUpdate());
        query.setParameter("before1Password", userDto.getBefore1Password());
        query.setParameter("before2Password", userDto.getBefore2Password());
        query.setParameter("userMei", userDto.getUserMei());
        query.setParameter("authGroupCd", userDto.getAuthGroupCd());
        query.setParameter("telNo", userDto.getTelNo());
        query.setParameter("soshiki1Cd", userDto.getSoshiki1Cd());
        query.setParameter("soshiki2Cd", userDto.getSoshiki2Cd());
        query.setParameter("soshiki3Cd", userDto.getSoshiki3Cd());
        query.setParameter("soshiki4Cd", userDto.getSoshiki4Cd());
        query.setParameter("soshiki5Cd", userDto.getSoshiki5Cd());
        query.setParameter("soshiki6Cd", userDto.getSoshiki6Cd());
        query.setParameter("soshikiNM", userDto.getSoshikiNM());
        query.setParameter("item01Cd", userDto.getItem01Cd());
        query.setParameter("item02Cd", userDto.getItem02Cd());
        query.setParameter("item03Cd", userDto.getItem03Cd());
        query.setParameter("item04Cd", userDto.getItem04Cd());
        query.setParameter("item05Cd", userDto.getItem05Cd());
        query.setParameter("item01Txt", userDto.getItem01Txt());
        query.setParameter("item02Txt", userDto.getItem02Txt());
        query.setParameter("item03Txt", userDto.getItem03Txt());
        query.setParameter("item04Txt", userDto.getItem04Txt());
        query.setParameter("item05Txt", userDto.getItem05Txt());
        query.setParameter("tourokuDt", userDto.getTourokuDt());
        query.setParameter("tourokuUserId", userDto.getTourokuUserId());
        query.setParameter("koushinDt", userDto.getKoushinDt());
        query.setParameter("koushinUserId", userDto.getKoushinUserId());
        query.setParameter("delFlg", userDto.getDelFlg());
        query.setParameter("delDt", userDto.getDelDt());
        query.setParameter("delUserID", userDto.getDelUserID());
        query.setParameter("soshiki7Cd", userDto.getSoshiki7Cd());
        query.setParameter("soshiki8Cd", userDto.getSoshiki8Cd());
        query.setParameter("soshiki9Cd", userDto.getSoshiki9Cd());
        query.setParameter("soshiki10Cd", userDto.getSoshiki10Cd());

        return (long) query.executeUpdate();
    }
}
