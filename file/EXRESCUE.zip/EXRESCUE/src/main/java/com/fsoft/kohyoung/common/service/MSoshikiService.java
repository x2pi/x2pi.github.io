package com.fsoft.kohyoung.common.service;

import java.util.List;
import com.fsoft.kohyoung.common.entity.MSoshiki;

/**
 * @author DungTM8
 *
 */
public interface MSoshikiService {

    public List<MSoshiki> getLstSoshiki(String useLevel, long groupId);
}