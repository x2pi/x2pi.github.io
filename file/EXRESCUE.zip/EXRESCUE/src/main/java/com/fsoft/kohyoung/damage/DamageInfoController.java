package com.fsoft.kohyoung.damage;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fsoft.kohyoung.common.abstracts.BaseController;

/**
 * Info Damage
 *
 * @author PhucPV
 */
@Controller
@RequestMapping("/damage/info")
public class DamageInfoController {

    @GetMapping
    public String index() {

	return "/damage/info";
    }


}
