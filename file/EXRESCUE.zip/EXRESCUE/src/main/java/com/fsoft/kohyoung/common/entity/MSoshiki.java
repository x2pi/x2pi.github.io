package com.fsoft.kohyoung.common.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * MSoshiki Entity
 * 
 * @author DungTM8
 */
@Entity
public class MSoshiki {

    @Id
    @Column(name="soshiki_kaisou_flg" , nullable = false)
    private int soshikiKaisouFlg;

    @Column(name="soshiki_cd", nullable = false)
    private String soshikiCd;

    @Column(name="soshiki_mei")
    private String soshikiMei;

    @Column(name="oya_soshiki_cd")
    private String oyaSoshikiCd;

    @Column(name="soshiki_status_cd")
    private String soshikiStatusCd;

    @Column(name="sort_seq")
    private int sortSeq;

    @Column(name="group_id")
    private long groupId;

    @Column(name="touroku_dt")
    private Timestamp tourokuDt;

    @Column(name="touroku_userid")
    private String tourokuUserid;

    @Column(name="koushin_dt")
    private Timestamp koushinDt;

    @Column(name="koushin_userid")
    private String koushinUserid;

    public int getSoshikiKaisouFlg() {
        return soshikiKaisouFlg;
    }

    public void setSoshikiKaisouFlg(int soshikiKaisouFlg) {
        this.soshikiKaisouFlg = soshikiKaisouFlg;
    }

    public String getSoshikiCd() {
        return soshikiCd;
    }

    public void setSoshikiCd(String soshikiCd) {
        this.soshikiCd = soshikiCd;
    }

    public String getSoshikiMei() {
        return soshikiMei;
    }

    public void setSoshikiMei(String soshikiMei) {
        this.soshikiMei = soshikiMei;
    }

    public String getOyaSoshikiCd() {
        return oyaSoshikiCd;
    }

    public void setOyaSoshikiCd(String oyaSoshikiCd) {
        this.oyaSoshikiCd = oyaSoshikiCd;
    }

    public String getSoshikiStatusCd() {
        return soshikiStatusCd;
    }

    public void setSoshikiStatusCd(String soshikiStatusCd) {
        this.soshikiStatusCd = soshikiStatusCd;
    }

    public int getSortSeq() {
        return sortSeq;
    }

    public void setSortSeq(int sortSeq) {
        this.sortSeq = sortSeq;
    }

    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(long groupId) {
        this.groupId = groupId;
    }

    public Timestamp getTourokuDt() {
        return tourokuDt;
    }

    public void setTourokuDt(Timestamp tourokuDt) {
        this.tourokuDt = tourokuDt;
    }

    public String getTourokuUserid() {
        return tourokuUserid;
    }

    public void setTourokuUserid(String tourokuUserid) {
        this.tourokuUserid = tourokuUserid;
    }

    public Timestamp getKoushinDt() {
        return koushinDt;
    }

    public void setKoushinDt(Timestamp koushinDt) {
        this.koushinDt = koushinDt;
    }

    public String getKoushinUserid() {
        return koushinUserid;
    }

    public void setKoushinUserid(String koushinUserid) {
        this.koushinUserid = koushinUserid;
    }
}
