package com.fsoft.kohyoung.common.service;

import java.util.List;
import com.fsoft.kohyoung.common.entity.MGroup;

/**
 * Group Service
 * 
 * @author DungTM8
 */
public interface MGroupService {

    public abstract List<MGroup> getLstGroup(String levelUser);
}