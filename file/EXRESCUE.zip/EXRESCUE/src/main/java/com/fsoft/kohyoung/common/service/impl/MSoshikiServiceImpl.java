package com.fsoft.kohyoung.common.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fsoft.kohyoung.common.abstracts.BaseService;
import com.fsoft.kohyoung.common.entity.MSoshiki;
import com.fsoft.kohyoung.common.repository.MSoshikiRepository;
import com.fsoft.kohyoung.common.service.MSoshikiService;

/**
 * @author DungTM8
 *
 */
@Service
public class MSoshikiServiceImpl extends BaseService implements MSoshikiService {

    @Autowired
    MSoshikiRepository mSoshikiRepository;

    @Override
    public List<MSoshiki> getLstSoshiki(String useLevel, long groupId) {
        return mSoshikiRepository.getLstSoshiki(useLevel, groupId);
    }
}