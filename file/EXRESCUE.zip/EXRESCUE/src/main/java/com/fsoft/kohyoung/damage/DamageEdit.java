package com.fsoft.kohyoung.damage;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fsoft.kohyoung.common.abstracts.BaseController;

/**
 * Edit Damage
 *
 * @author PhucPV
 */
@Controller
@RequestMapping("/damage/edit")
public class DamageEdit {
	
    @GetMapping
    public String index() {

        return "/damage/edit";
    }

}
