package com.fsoft.kohyoung.common.service;

import java.util.List;
import com.fsoft.kohyoung.common.entity.MCompany;

/**
 * @author DungTM8
 *
 */
public interface MCompanyService {

    public List<MCompany> getLstCompany(String userLevel, String soshiki);
}