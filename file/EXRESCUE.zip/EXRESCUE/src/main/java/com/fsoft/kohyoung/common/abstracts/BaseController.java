package com.fsoft.kohyoung.common.abstracts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

import com.fsoft.kohyoung.common.sysdate.SysdateManager;

/**
 * BaseController
 *
 * @author duongnguyen
 * @since 1.0.0
 */
public class BaseController {

    /*================================================================================================================
     *===== PROTECTED RESOURCE                                                                                   =====
     *================================================================================================================*/

    /** Protected Resource: Sysdate Manager */
    @Autowired
    protected SysdateManager sysdateManager;

    /** Protected Resource: MessageSource */
    @Autowired
    protected MessageSource messageSource;

    /*================================================================================================================
     *===== PROTECTED PROPERTIES                                                                                 =====
     *================================================================================================================*/

    /** Logger */
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    /*================================================================================================================
     *===== PROTECTED METHOD                                                                                     =====
     *================================================================================================================*/


}
