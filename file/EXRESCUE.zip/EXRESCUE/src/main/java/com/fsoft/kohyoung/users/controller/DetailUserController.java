package com.fsoft.kohyoung.users.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fsoft.kohyoung.common.abstracts.BaseController;
import com.fsoft.kohyoung.users.form.UserDetailForm;

/**
 * Detail User Screen
 *
 * @author DungTM8
 */
@RequestMapping({ "users/detail" })
@Controller
public class DetailUserController extends BaseController {

    @ModelAttribute
    public UserDetailForm setupForm() {
        return new UserDetailForm();
    }


    /**
     * Detail User Screen
     *
     * @return Detail user screen
     */
    @RequestMapping()
    public String index(UserDetailForm form, Model model) {
        return "users/detail";
    }
}
