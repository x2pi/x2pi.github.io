/**
 * 
 */
package com.fsoft.kohyoung.users.form;

/**
 * @author DungTM8
 *
 */
public class UserListForm extends UserCommonForm {
	
	protected String errorMsg;
	
	protected String accountStat;
	
	protected String initShozokubuCd;
	
	protected String limit;
	
	protected String offset;
	
	protected String sortkey;
	
	protected String ascdesc;
	
	protected String issort;
	
	protected String procStat;
	
	protected String kaisouTabKind;
	
	
	public String getAccountStat() {
		return accountStat;
	}

	public void setAccountStat(String accountStat) {
		this.accountStat = accountStat;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getInitShozokubuCd() {
		return initShozokubuCd;
	}

	public void setInitShozokubuCd(String initShozokubuCd) {
		this.initShozokubuCd = initShozokubuCd;
	}

	public String getLimit() {
		return limit;
	}

	public void setLimit(String limit) {
		this.limit = limit;
	}

	public String getOffset() {
		return offset;
	}

	public void setOffset(String offset) {
		this.offset = offset;
	}

	public String getSortkey() {
		return sortkey;
	}

	public void setSortkey(String sortkey) {
		this.sortkey = sortkey;
	}

	public String getAscdesc() {
		return ascdesc;
	}

	public void setAscdesc(String ascdesc) {
		this.ascdesc = ascdesc;
	}

	public String getIssort() {
		return issort;
	}

	public void setIssort(String issort) {
		this.issort = issort;
	}

	public String getProcStat() {
		return procStat;
	}

	public void setProcStat(String procStat) {
		this.procStat = procStat;
	}

	public String getKaisouTabKind() {
		return kaisouTabKind;
	}

	public void setKaisouTabKind(String kaisouTabKind) {
		this.kaisouTabKind = kaisouTabKind;
	}
	
	

}
