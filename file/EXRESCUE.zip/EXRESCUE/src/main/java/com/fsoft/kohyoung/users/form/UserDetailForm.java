package com.fsoft.kohyoung.users.form;

/**
 * Form for detail user
 *
 * @author DungTM8
 */
public class UserDetailForm extends UserCommonForm {
	
	protected String koushinDt;

	public String getKoushinDt() {
		return koushinDt;
	}

	public void setKoushinDt(String koushinDt) {
		this.koushinDt = koushinDt;
	}
	

}
