package com.fsoft.kohyoung.damage;

public class DamageSearchForm {
    	private String country;
	private String damageCondition;
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getDamageCondition() {
	    return damageCondition;
	}
	public void setDamageCondition(String damageCondition) {
	    this.damageCondition = damageCondition;
	}

}
