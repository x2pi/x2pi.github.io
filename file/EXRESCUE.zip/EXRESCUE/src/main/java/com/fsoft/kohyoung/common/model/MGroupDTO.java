package com.fsoft.kohyoung.common.model;

import java.sql.Timestamp;

/**
 * @author DungTM8
 *
 */
public class MGroupDTO {

    private String groupId;

    private String groupMei;

    private Timestamp tourokuDt;

    private String tourokuUserid;

    private Timestamp koushinDt;

    private String koushinUserid;

    private int groupLat;

    private int groupLon;

    private String iconMei;

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getGroupMei() {
        return groupMei;
    }

    public void setGroupMei(String groupMei) {
        this.groupMei = groupMei;
    }

    public Timestamp getTourokuDt() {
        return tourokuDt;
    }

    public void setTourokuDt(Timestamp tourokuDt) {
        this.tourokuDt = tourokuDt;
    }

    public String getTourokuUserid() {
        return tourokuUserid;
    }

    public void setTourokuUserid(String tourokuUserid) {
        this.tourokuUserid = tourokuUserid;
    }

    public Timestamp getKoushinDt() {
        return koushinDt;
    }

    public void setKoushinDt(Timestamp koushinDt) {
        this.koushinDt = koushinDt;
    }

    public String getKoushinUserid() {
        return koushinUserid;
    }

    public void setKoushinUserid(String koushinUserid) {
        this.koushinUserid = koushinUserid;
    }

    public double getGroupLat() {
        return groupLat;
    }

    public void setGroupLat(int groupLat) {
        this.groupLat = groupLat;
    }

    public double getGroupLon() {
        return groupLon;
    }

    public void setGroupLon(int groupLon) {
        this.groupLon = groupLon;
    }

    public String getIconMei() {
        return iconMei;
    }

    public void setIconMei(String iconMei) {
        this.iconMei = iconMei;
    }
}
