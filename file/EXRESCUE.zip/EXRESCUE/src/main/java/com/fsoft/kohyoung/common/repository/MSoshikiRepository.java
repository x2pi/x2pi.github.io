package com.fsoft.kohyoung.common.repository;

import java.util.List;
import com.fsoft.kohyoung.common.entity.MSoshiki;

/**
 * @author DungTM8
 *
 */
public interface MSoshikiRepository {

    public List<MSoshiki> getLstSoshiki(String useLevel, long groupId);
}