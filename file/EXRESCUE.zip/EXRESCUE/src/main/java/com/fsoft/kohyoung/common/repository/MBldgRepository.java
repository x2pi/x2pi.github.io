package com.fsoft.kohyoung.common.repository;

import java.util.List;
import com.fsoft.kohyoung.common.entity.MBldg;

/**
 * @author DungTM8
 *
 */
public interface MBldgRepository {

    public List<MBldg> getLstBldg(String uselevel, String soshiki, long company);
}