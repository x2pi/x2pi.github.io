package com.fsoft.kohyoung.common.model;

import java.sql.Timestamp;

/**
 * @author DungTM8
 *
 */
public class MBldgDTO {

    private long id;

    private String bldgCd;

    private long companyId;

    private String bldgMei;

    private String floor_mei;

    private String juusho;

    private double latitude;

    private double longitude;

    private int matchingLevel;

    private String postalCodeNumber;

    private String telNo;

    private String faxNo;

    private String daihyoushaMei;

    private String bikou;

    private Timestamp tourokuDt;

    private String tourokuUserid;

    private Timestamp koushinDt;

    private String koushinUserid;

    private int delFlg;

    private Timestamp delDt;

    private String delUserid;

    private String soshikiCd;

    private String todoufukenCd;

    private String shikuchousonCd;

    private int groupId;

    private String hoboCd;

    private String shoyuushaMei;

    private String freeItem1;

    private String freeItem2;

    private String freeItem3;

    private String freeItem4;

    private String freeItem5;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getBldgCd() {
        return bldgCd;
    }

    public void setBldgCd(String bldgCd) {
        this.bldgCd = bldgCd;
    }

    public long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(long companyId) {
        this.companyId = companyId;
    }

    public String getBldgMei() {
        return bldgMei;
    }

    public void setBldgMei(String bldgMei) {
        this.bldgMei = bldgMei;
    }

    public String getFloor_mei() {
        return floor_mei;
    }

    public void setFloor_mei(String floor_mei) {
        this.floor_mei = floor_mei;
    }

    public String getJuusho() {
        return juusho;
    }

    public void setJuusho(String juusho) {
        this.juusho = juusho;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public int getMatchingLevel() {
        return matchingLevel;
    }

    public void setMatchingLevel(int matchingLevel) {
        this.matchingLevel = matchingLevel;
    }

    public String getPostalCodeNumber() {
        return postalCodeNumber;
    }

    public void setPostalCodeNumber(String postalCodeNumber) {
        this.postalCodeNumber = postalCodeNumber;
    }

    public String getTelNo() {
        return telNo;
    }

    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    public String getFaxNo() {
        return faxNo;
    }

    public void setFaxNo(String faxNo) {
        this.faxNo = faxNo;
    }

    public String getDaihyoushaMei() {
        return daihyoushaMei;
    }

    public void setDaihyoushaMei(String daihyoushaMei) {
        this.daihyoushaMei = daihyoushaMei;
    }

    public String getBikou() {
        return bikou;
    }

    public void setBikou(String bikou) {
        this.bikou = bikou;
    }

    public Timestamp getTourokuDt() {
        return tourokuDt;
    }

    public void setTourokuDt(Timestamp tourokuDt) {
        this.tourokuDt = tourokuDt;
    }

    public String getTourokuUserid() {
        return tourokuUserid;
    }

    public void setTourokuUserid(String tourokuUserid) {
        this.tourokuUserid = tourokuUserid;
    }

    public Timestamp getKoushinDt() {
        return koushinDt;
    }

    public void setKoushinDt(Timestamp koushinDt) {
        this.koushinDt = koushinDt;
    }

    public String getKoushinUserid() {
        return koushinUserid;
    }

    public void setKoushinUserid(String koushinUserid) {
        this.koushinUserid = koushinUserid;
    }

    public int getDelFlg() {
        return delFlg;
    }

    public void setDelFlg(int delFlg) {
        this.delFlg = delFlg;
    }

    public Timestamp getDelDt() {
        return delDt;
    }

    public void setDelDt(Timestamp delDt) {
        this.delDt = delDt;
    }

    public String getDelUserid() {
        return delUserid;
    }

    public void setDelUserid(String delUserid) {
        this.delUserid = delUserid;
    }

    public String getSoshikiCd() {
        return soshikiCd;
    }

    public void setSoshikiCd(String soshikiCd) {
        this.soshikiCd = soshikiCd;
    }

    public String getTodoufukenCd() {
        return todoufukenCd;
    }

    public void setTodoufukenCd(String todoufukenCd) {
        this.todoufukenCd = todoufukenCd;
    }

    public String getShikuchousonCd() {
        return shikuchousonCd;
    }

    public void setShikuchousonCd(String shikuchousonCd) {
        this.shikuchousonCd = shikuchousonCd;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getHoboCd() {
        return hoboCd;
    }

    public void setHoboCd(String hoboCd) {
        this.hoboCd = hoboCd;
    }

    public String getShoyuushaMei() {
        return shoyuushaMei;
    }

    public void setShoyuushaMei(String shoyuushaMei) {
        this.shoyuushaMei = shoyuushaMei;
    }

    public String getFreeItem1() {
        return freeItem1;
    }

    public void setFreeItem1(String freeItem1) {
        this.freeItem1 = freeItem1;
    }

    public String getFreeItem2() {
        return freeItem2;
    }

    public void setFreeItem2(String freeItem2) {
        this.freeItem2 = freeItem2;
    }

    public String getFreeItem3() {
        return freeItem3;
    }

    public void setFreeItem3(String freeItem3) {
        this.freeItem3 = freeItem3;
    }

    public String getFreeItem4() {
        return freeItem4;
    }

    public void setFreeItem4(String freeItem4) {
        this.freeItem4 = freeItem4;
    }

    public String getFreeItem5() {
        return freeItem5;
    }

    public void setFreeItem5(String freeItem5) {
        this.freeItem5 = freeItem5;
    }
}
