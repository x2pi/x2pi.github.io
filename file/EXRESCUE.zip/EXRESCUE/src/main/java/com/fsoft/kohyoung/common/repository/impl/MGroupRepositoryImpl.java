package com.fsoft.kohyoung.common.repository.impl;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.fsoft.kohyoung.common.abstracts.BaseRepository;
import com.fsoft.kohyoung.common.entity.MGroup;
import com.fsoft.kohyoung.common.repository.MGroupRepository;

/**
 * @author DungTM8
 *
 */
@Repository
public class MGroupRepositoryImpl extends BaseRepository implements MGroupRepository {

    @SuppressWarnings("unchecked")
    @Override
    public List<MGroup> getLstGroup(String levelUser) {
        List<MGroup> lstMGroup = new ArrayList<>();
        String query = "SELECT gr FROM MGroup as gr";
        lstMGroup = entityManager.createQuery(query).getResultList();
        return lstMGroup;
    }
}