package com.fsoft.kohyoung.common.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fsoft.kohyoung.common.abstracts.BaseService;
import com.fsoft.kohyoung.common.entity.MHanyou;
import com.fsoft.kohyoung.common.repository.MHanyouRepository;
import com.fsoft.kohyoung.common.service.MHanyouService;

/**
 * MHanyou Service Implement
 * 
 * @author DungTM8
 */
@Service
public class MHanyouServiceImpl extends BaseService implements MHanyouService{

    /** mHanyou Repository */
    @Autowired
    MHanyouRepository mHanyouRepository;

    @Override
    public List<MHanyou> selectLstBunruiCd(String param) {
        return mHanyouRepository.selectLstBunruiCd(param);
    }
}