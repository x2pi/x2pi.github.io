package com.fsoft.kohyoung.common.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * @author DungTM8
 *
 */
@Entity
public class MHanyou implements Serializable{

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="hanyou_bunrui_cd", nullable = false)
    private String hanyouBunruiCd;

    @Id
    @Column(name="hanyou_cd", nullable = false)
    private String hanyouCd;
    
    @Column(name="hanyou_bunrui_mei")
    private String hanyouBunruiMei;

    @Column(name="hanyou_cd_value")
    private String hanyouCdValue;

    @Column(name="hanyou_cd_sort")
    private Integer hanyouCdSort;

    @Column(name="hanyou_cd_1byte")
    private String hanyouCd1byte;

    @Column(name="hanyou_bikou")
    private String hanyouBikou;

    @Column(name="kanren_cd")
    private String kanrenCd;

    @Column(name="touroku_dt")
    private Timestamp tourokuDt;

    @Column(name="koushin_dt")
    private Timestamp koushinDt;
    
    public String getHanyouBunruiCd() {
        return hanyouBunruiCd;
    }

    public void setHanyouBunruiCd(String hanyouBunruiCd) {
        this.hanyouBunruiCd = hanyouBunruiCd;
    }

    public String getHanyouCd() {
        return hanyouCd;
    }

    public void setHanyouCd(String hanyouCd) {
        this.hanyouCd = hanyouCd;
    }

    public String getHanyouBunruiMei() {
        return hanyouBunruiMei;
    }

    public void setHanyouBunruiMei(String hanyouBunruiMei) {
        this.hanyouBunruiMei = hanyouBunruiMei;
    }

    public String getHanyouCdValue() {
        return hanyouCdValue;
    }

    public void setHanyouCdValue(String hanyouCdValue) {
        this.hanyouCdValue = hanyouCdValue;
    }

    public Integer getHanyouCdSort() {
        return hanyouCdSort;
    }

    public void setHanyouCdSort(Integer hanyouCdSort) {
        this.hanyouCdSort = hanyouCdSort;
    }

    public String getHanyouCd1byte() {
        return hanyouCd1byte;
    }

    public void setHanyouCd1byte(String hanyouCd1byte) {
        this.hanyouCd1byte = hanyouCd1byte;
    }

    public String getHanyouBikou() {
        return hanyouBikou;
    }

    public void setHanyouBikou(String hanyouBikou) {
        this.hanyouBikou = hanyouBikou;
    }

    public String getKanrenCd() {
        return kanrenCd;
    }

    public void setKanrenCd(String kanrenCd) {
        this.kanrenCd = kanrenCd;
    }

    public Timestamp getTourokuDt() {
        return tourokuDt;
    }

    public void setTourokuDt(Timestamp tourokuDt) {
        this.tourokuDt = tourokuDt;
    }

    public Timestamp getKoushinDt() {
        return koushinDt;
    }

    public void setKoushinDt(Timestamp koushinDt) {
        this.koushinDt = koushinDt;
    }
}
