package com.fsoft.kohyoung.common.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * @author DungTM8
 *
 */
@Entity
public class MCompany {

    @Id
    @Column(name="company_id", nullable = false)
    private long companyId;

    @Column(name="company_mei")
    private String companyMei;

    @Column(name="touroku_dt")
    private Timestamp tourokuDt;

    @Column(name="touroku_userid")
    private String tourokuUserid;

    @Column(name="koushin_dt")
    private Timestamp koushinDt;

    @Column(name="koushin_userid")
    private String koushinUserid;

    @Column(name="soshiki_cd" , nullable = false)
    private String soshikiCd;

    public long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(long companyId) {
        this.companyId = companyId;
    }

    public String getCompanyMei() {
        return companyMei;
    }

    public void setCompanyMei(String companyMei) {
        this.companyMei = companyMei;
    }

    public Timestamp getTourokuDt() {
        return tourokuDt;
    }

    public void setTourokuDt(Timestamp tourokuDt) {
        this.tourokuDt = tourokuDt;
    }

    public String getTourokuUserid() {
        return tourokuUserid;
    }

    public void setTourokuUserid(String tourokuUserid) {
        this.tourokuUserid = tourokuUserid;
    }

    public Timestamp getKoushinDt() {
        return koushinDt;
    }

    public void setKoushinDt(Timestamp koushinDt) {
        this.koushinDt = koushinDt;
    }

    public String getKoushinUserid() {
        return koushinUserid;
    }

    public void setKoushinUserid(String koushinUserid) {
        this.koushinUserid = koushinUserid;
    }

    public String getSoshikiCd() {
        return soshikiCd;
    }

    public void setSoshikiCd(String soshikiCd) {
        this.soshikiCd = soshikiCd;
    }
}
