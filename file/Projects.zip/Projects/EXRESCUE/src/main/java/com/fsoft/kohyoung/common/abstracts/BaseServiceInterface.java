package com.fsoft.kohyoung.common.abstracts;

/**
 * io.cobrafw.iam.common.abstracts -> BaseServiceInterface
 *
 * @author duongnguyen
 * @since 1.0.0
 */
public interface BaseServiceInterface {


}
