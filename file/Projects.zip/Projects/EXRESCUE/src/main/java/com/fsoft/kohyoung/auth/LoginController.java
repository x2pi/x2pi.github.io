package com.fsoft.kohyoung.auth;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fsoft.kohyoung.common.abstracts.BaseController;

/**
 * Authenticate -> Login controller
 *
 * @author duongnguyen
 */
@Controller
@RequestMapping("/auth/login")
public class LoginController extends BaseController {

    /**
     * Show login form
     *
     * @return Login input screen
     */
    @GetMapping
    public String input() {

        return "/auth/login";
    }

    /**
     * Attempt login
     *
     * @return  Redirect to home page
     */
    @PostMapping
    public String submit() {

        return "redirect:/";
    }
}
