package com.fsoft.kohyoung.users.form;

/**
 * 
 *
 * @author duongnguyen 
 */
public class UserSearchForm {

}
