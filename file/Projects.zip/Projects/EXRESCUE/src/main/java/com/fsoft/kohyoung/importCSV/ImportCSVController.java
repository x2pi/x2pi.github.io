/**
 * 
 */
package com.fsoft.kohyoung.importCSV;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Import CSV controller
 * 
 * @author TungLD2
 *
 */
@Controller
@RequestMapping("/import")
public class ImportCSVController {
	/**
	 * Show import screen
	 *
	 * @return import screen
	 */
	@GetMapping
	public String index(ModelMap model) {

		return "import/import";
	}

}
