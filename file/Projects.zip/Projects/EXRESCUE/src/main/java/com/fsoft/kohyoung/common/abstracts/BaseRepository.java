package com.fsoft.kohyoung.common.abstracts;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.fsoft.kohyoung.common.sysdate.SysdateManager;

/**
 * io.cobrafw.iam.common.abstracts -> BaseRepository
 *
 * @author duongnguyen
 * @since 1.0.0
 */
public class BaseRepository implements BaseRepositoryInterface {

    /*================================================================================================================
     *===== PROTECTED PROPERTIES                                                                                 =====
     *================================================================================================================*/

    /**
     * Logger
     */
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * Protected Resource: JPA Entity Manager
     */
    @Autowired
    protected EntityManager entityManager;

    /**
     * Protected Resource: Sysdate Manager
     */
    @Autowired
    protected SysdateManager sysdateManager;

    /*================================================================================================================
     *===== PROTECTED METHOD                                                                                     =====
     *================================================================================================================*/

    /**
     * UnWrap Hibernate session
     *
     * @return Current hibernate session
     */
    protected Session getCurrentSession() {
        return entityManager.unwrap(Session.class);
    }

    /*================================================================================================================
     *===== PUBLIC METHOD                                                                                        =====
     *================================================================================================================*/

}
