package com.fsoft.kohyoung.common.abstracts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.fsoft.kohyoung.common.sysdate.SysdateManager;

/**
 * io.cobrafw.iam.common.abstracts -> BaseService
 *
 * @author duongnguyen
 * @since 1.0.0
 */
@Transactional
public abstract class BaseService implements BaseServiceInterface {

    /*================================================================================================================
     *===== PROTECTED PROPERTIES                                                                                 =====
     *================================================================================================================*/

    /** Logger */
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * Protected Resource: Sysdate Manager
     */
    @Autowired
    protected SysdateManager sysdateManager;

    /*================================================================================================================
     *===== PROTECTED METHOD                                                                                     =====
     *================================================================================================================*/


    /*================================================================================================================
     *===== PUBLIC METHOD                                                                                        =====
     *================================================================================================================*/

}
