package com.fsoft.kohyoung.users.form;

/**
 * User Update form
 *
 * @author duongnguyen
 */
public class UserUpdateForm {

}
